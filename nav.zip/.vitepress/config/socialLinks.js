module.exports = [
  { icon: "github", link: "https://github.com/huangpw/vitepress-navigation-resource" },
];
