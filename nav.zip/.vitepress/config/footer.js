module.exports = {
  message: 'Released under the MIT License.如有转载或 CV 的请标注本站原文地址',
  // message: `<a href="https://beian.miit.gov.cn/" target="_blank">京ICP备2001661114号-2</a>`,
  copyright: 'Copyright © 2025-present Huangpw',
  // Copyright © 2021-2023 www.layui-vue.com
};
