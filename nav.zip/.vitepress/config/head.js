module.exports = [
    ["link", { rel: "shortcut icon", href: "/vitepress-navigation-resource/favicon.ico" }],
    ["link", { rel: "icon", href: "/vitepress-navigation-resource/favicon.ico" }],
    ['meta', { name: 'msapplication-TileImage', content: '/vitepress-navigation-resource/favicon.ico' }],
    ['link', { rel: 'mask-icon', href: '/vitepress-navigation-resource/favicon.ico', color: '#3eaf7c' }],
]