export const FRIEND_DATA = [
  {
    title: '网站链接',
    items: [
      {
        title: "肯了个德的博客",
        desc: "专注于分享没用的知识，你乐意看就多看看，保证你一看一个不吱声",
        link: "https://leelaa.cn",
        icon: "https://leelaa.cn/logo.webp"
      },
      {
        title: "粥里有勺糖",
        desc: "你的指尖，拥有改变世界的力量",
        link: "https://sugarat.top",
        icon: "https://sugarat.top/logo.png"
      },
      {
        title: "骤雨重山",
        desc: "运气是计划之外的东西",
        link: "https://www.vvhan.com",
        icon: "https://q1.qlogo.cn/g?b=qq&nk=1655466387&s=640"
      },
      {
        title: "肯了个德的博客",
        desc: "专注于分享没用的知识，你乐意看就多看看，保证你一看一个不吱声",
        link: "https://leelaa.cn",
        icon: "https://leelaa.cn/logo.webp"
      },
      {
        title: "粥里有勺糖",
        desc: "你的指尖，拥有改变世界的力量",
        link: "https://sugarat.top",
        icon: "https://sugarat.top/logo.png"
      },
      {
        title: "骤雨重山",
        desc: "运气是计划之外的东西",
        link: "https://www.vvhan.com",
        icon: "https://q1.qlogo.cn/g?b=qq&nk=1655466387&s=640"
      }
    ]
  }
]
