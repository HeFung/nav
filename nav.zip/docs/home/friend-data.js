export const FRIEND_DATA = [
  {
    title: '网站链接',
    items: [
      {
        icon: '/icons/html.png',
        title: '前端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
      {
        icon: '/icons/html.png',
        title: '后端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
      {
        icon: '/icons/html.png',
        title: '移动端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
      {
        icon: '/icons/html.png',
        title: '数据库端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
      {
        icon: '/icons/html.png',
        title: '服务端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
      {
        icon: '/icons/html.png',
        title: '软件端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
      {
        icon: '/icons/html.png',
        title: '笔记端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
      {
        icon: '/icons/html.png',
        title: '其他端-资源库',
        desc: '前端Vue学习网站，收录web端&移动端&小程序端等官网，项目开箱即用，实战笔记。',
        link: 'https://huangpw.github.io/vitepress-frontend-resource/'
      },
    ]
  }
]
