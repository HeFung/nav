export const NAV_DATA = [
  {
    title: '综合学习',
    items: [
      {
        icon: '/icons/51zxwkf.png',
        title: '第一教程网',
        desc: '专注于提供最全最实用的教育教学视频教程免费在线观看学习,主要包含电脑、外语、中小学、大学、考研、资格、技能、医学体育、舞蹈音乐、农业、家居等。',
        link: 'http://www.51zxwkf.net/index-2.html',
        badge: '官网',
      },
    ],
  },
];
